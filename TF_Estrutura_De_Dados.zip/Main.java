import java.util.Scanner;
public class Main {

    static int proximoNumero = 1;

    static Scanner sc = new Scanner(System.in);

    static ControlarChamados controle = new ControlarChamados();
    static FilaChamados fila = new FilaChamados();
    static ArvoreClientes arvore = new ArvoreClientes();


    public static void main(String[] args) {
        int opcao;

        do {
            System.out.println("\n======== HELP DESK ========");
            System.out.println("1 - Cadastrar cliente");
            System.out.println("2 - Buscar cliente");
            System.out.println("3 - Remover cliente");
            System.out.println("4 - Lista de clientes");
            System.out.println("5 - Abrir chamado");
            System.out.println("6 - Lista de chamados aguardando");
            System.out.println("7 - Atender próximo chamado");
            System.out.println("8 - Adicionar mensagem");
            System.out.println("9 - Consultar histórico");
            System.out.println("10 - Encerrar chamado");
            System.out.println("0 - Sair");


            System.out.print("Escolha uma opção: ");
            opcao = sc.nextInt();
            sc.nextLine();


            switch (opcao) {

                case 1:
                    cadastrarCliente();
                    break;

                case 2:
                    buscarCliente();
                    break;

                case 3:
                    removerCliente();
                    break;

                case 4:
                    listarClientes();
                    break;

                case 5:
                    abrirChamado();
                    break;

                case 6:
                    listarChamados();
                    break;

                case 7:
                    atenderChamado();
                    break;

                case 8:
                    adicionarMensagem();
                    break;

                case 9:
                    consultarHistorico();
                    break;

                case 10:
                    encerrarChamado();
                    break;

                case 0:
                    System.out.println("Sistema encerrado!");
                    break;

                default:
                    System.out.println("Opção inválida!");
            }

        } while (opcao != 0);
        sc.close();
    }


    public static void cadastrarCliente() {
        System.out.println("\n===== CADASTRO DE CLIENTE =====");

        System.out.print("Digite o CPF ou CNPJ: ");
        String documento = sc.nextLine();

        if (arvore.buscar(documento) != null) {
            System.out.println("Este cliente já está cadastrado!");
            return;
        }

        
        System.out.print("Digite o nome: ");
        String nome = sc.nextLine();

        System.out.print("Digite o telefone: ");
        String telefone = sc.nextLine();

        System.out.print("Digite o e-mail: ");
        String email = sc.nextLine();

        Cliente novo = new Cliente(
                documento, nome, telefone, email
        );

        arvore.inserir(novo);

        System.out.println("Cadastro realizado!");
    }





    public static void buscarCliente() {
        System.out.println("\n===== BUSCAR CLIENTE =====");

        System.out.print("Digite o CPF ou CNPJ: ");
        String documento = sc.nextLine();

        Cliente encontrado = arvore.buscar(documento);

        if (encontrado != null) {
            System.out.println("\nCliente encontrado!");
            System.out.println("Documento: " + encontrado.documento);
            System.out.println("Nome: " + encontrado.nome);
            System.out.println("Telefone: " + encontrado.telefone);
            System.out.println("E-mail: " + encontrado.email);
        } else {
            System.out.println("Cliente não encontrado!");
        }
    }





    public static void removerCliente() {
        System.out.println("\n===== REMOVER CLIENTE =====");

        System.out.print("Digite o CPF ou CNPJ: ");
        String documento = sc.nextLine();

        Cliente encontrado = arvore.buscar(documento);

        if (encontrado != null) {
            arvore.remover(documento);
            System.out.println("Cliente removido com sucesso!");
        } else {
            System.out.println("Cliente não encontrado!");
        }
    }




    public static void listarClientes() {

        if (arvore.estaVazia()) {
            System.out.println("Não existem clientes cadastrados.");
            return;
        }

        System.out.println("\n===== CLIENTES EM ORDEM =====");
        arvore.emOrdem();

        System.out.println("\n===== CLIENTES EM PRE-ORDEM =====");
        arvore.preOrdem();

        System.out.println("\n===== CLIENTES EM POS-ORDEM =====");
        arvore.posOrdem();
    }





    public static void abrirChamado() {

        System.out.println("\n===== ABRIR CHAMADO =====");

        System.out.print("Digite o CPF ou CNPJ do cliente: ");
        String documento = sc.nextLine();

        Cliente cliente = arvore.buscar(documento);

        if (cliente == null) {
            System.out.println("Cliente não encontrado!");
            return;
        }

        System.out.print("Digite o assunto: ");
        String assunto = sc.nextLine();

        System.out.print("Descreva o problema: ");
        String descricao = sc.nextLine();

        Chamado novo = new Chamado(
                proximoNumero,
                documento,
                assunto,
                descricao
        );

        controle.adicionar(novo);
        fila.adicionar(novo);

        System.out.println("\nChamado aberto com sucesso!");
        System.out.println("Número do chamado: " + proximoNumero);

        proximoNumero++;
    }




    public static void listarChamados() {

        System.out.println("\n===== CHAMADOS AGUARDANDO =====");

        fila.listar();

    }




    public static void atenderChamado() {

        System.out.println("\n===== ATENDER CHAMADO =====");

        Chamado atendido = fila.remover();

        if (atendido == null) {
            System.out.println("Não existem chamados aguardando atendimento.");
            return;
        }

        atendido.status = "Em atendimento";

        System.out.println("\nChamado selecionado!");
        System.out.println("Número: " + atendido.numero);
        System.out.println("Cliente: " + atendido.documentoCliente);
        System.out.println("Assunto: " + atendido.assunto);
        System.out.println("Descrição: " + atendido.descricao);
        System.out.println("Status: " + atendido.status);
    }




    public static void adicionarMensagem() {

        System.out.println("\n===== ADICIONAR MENSAGEM =====");

        System.out.print("Digite o número do chamado: ");
        int numero = sc.nextInt();
        sc.nextLine();

        Chamado chamado = controle.buscar(numero);

        if (chamado == null) {
            System.out.println("Chamado não encontrado!");
            return;
        }

        System.out.println("Quem está enviando a mensagem?");
        System.out.println("1 - Cliente");
        System.out.println("2 - Técnico");
        System.out.print("Escolha: ");

        int opcao = sc.nextInt();
        sc.nextLine();

        String autor;

        if (opcao == 1) {
            autor = "Cliente";
        } else if (opcao == 2) {
            autor = "Técnico";
        } else {
            System.out.println("Opção inválida!");
            return;
        }

        System.out.print("Digite a mensagem: ");
        String conteudo = sc.nextLine();

        Mensagem nova = new Mensagem(autor, conteudo);

        chamado.historico.adicionar(nova);

        System.out.println("Mensagem adicionada com sucesso!");
    }




    public static void consultarHistorico() {

        System.out.println("\n===== HISTÓRICO DO CHAMADO =====");

        System.out.print("Digite o número do chamado: ");
        int numero = sc.nextInt();
        sc.nextLine();

        Chamado chamado = controle.buscar(numero);

        if (chamado == null) {
            System.out.println("Chamado não encontrado!");
            return;
        }

        System.out.println("\nChamado: " + chamado.numero);
        System.out.println("Assunto: " + chamado.assunto);
        System.out.println("Status: " + chamado.status);

        if (chamado.historico.estaVazio()) {
            System.out.println("Este chamado ainda não possui mensagens.");
            return;
        }

        System.out.println("\nMensagens:");

        chamado.historico.listar();
    }



    public static void encerrarChamado() {

        System.out.println("\n===== ENCERRAR CHAMADO =====");

        System.out.print("Digite o número do chamado: ");
        int numero = sc.nextInt();
        sc.nextLine();

        Chamado chamado = controle.buscar(numero);

        if (chamado == null) {
            System.out.println("Chamado não encontrado!");
            return;
        }

        if (chamado.status.equals("Concluído")) {
            System.out.println("Este chamado já foi encerrado!");
            return;
        }

        if (chamado.status.equals("Aguardando")) {
            System.out.println("Este chamado ainda está aguardando atendimento.");
            System.out.println("Atenda-o antes de encerrar.");
            return;
        }

        chamado.status = "Concluído";

        System.out.println("Chamado encerrado com sucesso!");
    }

}


