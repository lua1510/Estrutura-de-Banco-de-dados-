public class ArvoreClientes {
    NoArvore raiz;

    public void inserir (Cliente cliente){
        raiz = inserirRecursivo ( raiz, cliente);
    }

    private NoArvore inserirRecursivo ( NoArvore atual, Cliente cliente){
        if(atual==null){
            return new NoArvore(cliente);
        }
        int comparacao = cliente.documento.compareTo(atual.cliente.documento);

        if (comparacao < 0) {
            atual.esquerda = inserirRecursivo(atual.esquerda, cliente);
        } else if (comparacao > 0) {
            atual.direita = inserirRecursivo(atual.direita, cliente);
        } else {
            System.out.println("Cliente já cadastrado!");
        }

        return atual;
    }


    public Cliente buscar(String documento) {
        NoArvore resultado = buscarRecursivo(raiz, documento);

        if (resultado == null) {
            return null;
        }

        return resultado.cliente;
    }

    private NoArvore buscarRecursivo(NoArvore atual, String documento) {
        if (atual == null || atual.cliente.documento.equals(documento)) {
            return atual;
        }

        int comparacao = documento.compareTo(atual.cliente.documento);

        if (comparacao < 0) {
            return buscarRecursivo(atual.esquerda, documento);
        }

        return buscarRecursivo(atual.direita, documento);
    }



    public void remover(String documento) {
        raiz = removerRecursivo(raiz, documento);
    }

    private NoArvore removerRecursivo(NoArvore atual, String documento) {
        if (atual == null) {
            return null;
        }

        int comparacao = documento.compareTo(atual.cliente.documento);

        if (comparacao < 0) {
            atual.esquerda = removerRecursivo(atual.esquerda, documento);
        } else if (comparacao > 0) {
            atual.direita = removerRecursivo(atual.direita, documento);
        } else {
            if (atual.esquerda == null) {
                return atual.direita;
            }

            if (atual.direita == null) {
                return atual.esquerda;
            }

            NoArvore sucessor = encontrarMenor(atual.direita);
            atual.cliente = sucessor.cliente;
            atual.direita = removerRecursivo(
                    atual.direita, sucessor.cliente.documento
            );
        }

        return atual;
    }

    private NoArvore encontrarMenor(NoArvore atual) {
        while (atual.esquerda != null) {
            atual = atual.esquerda;
        }

        return atual;
    }


    public void emOrdem() {
        emOrdemRecursivo(raiz);
    }

    private void emOrdemRecursivo(NoArvore atual) {
        if (atual != null) {
            emOrdemRecursivo(atual.esquerda);
            System.out.println(atual.cliente.documento + " - " + atual.cliente.nome);
            emOrdemRecursivo(atual.direita);
        }
    }

    public void preOrdem() {
        preOrdemRecursivo(raiz);
    }

    private void preOrdemRecursivo(NoArvore atual) {
        if (atual != null) {
            System.out.println(atual.cliente.documento + " - " + atual.cliente.nome);
            preOrdemRecursivo(atual.esquerda);
            preOrdemRecursivo(atual.direita);
        }
    }

    public void posOrdem() {
        posOrdemRecursivo(raiz);
    }

    private void posOrdemRecursivo(NoArvore atual) {
        if (atual != null) {
            posOrdemRecursivo(atual.esquerda);
            posOrdemRecursivo(atual.direita);
            System.out.println(atual.cliente.documento + " - " + atual.cliente.nome);
        }
    }


    public boolean estaVazia() {
        return raiz == null;
    }

}
