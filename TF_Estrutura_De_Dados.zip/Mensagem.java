public class Mensagem {
    String autor;
    String conteudo;

    public Mensagem(String autor, String conteudo) {
        this.autor = autor;
        this.conteudo = conteudo;
    }
}
