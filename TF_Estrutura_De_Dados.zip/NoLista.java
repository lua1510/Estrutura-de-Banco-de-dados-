public class NoLista {
    Mensagem mensagem;
    NoLista proximo;

    public NoLista(Mensagem mensagem) {
        this.mensagem = mensagem;
        this.proximo = null;
    }
}
