public class Chamado {
    int numero;
    String documentoCliente;
    String assunto;
    String descricao;
    String status;
    HitoricoChamada historico;

    public Chamado ( int numero, String documentoCliente, String assunto, String descricao){
        this.numero = numero;
        this.documentoCliente = documentoCliente;
        this.assunto = assunto;
        this.descricao = descricao;
        this.status = "Aguardando";
        this.historico = new HitoricoChamada();

    }



}
