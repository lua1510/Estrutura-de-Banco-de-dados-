public class NoArvore {
    Cliente cliente;
    NoArvore esquerda;
    NoArvore direita;

    public NoArvore ( Cliente cliente){
        this.cliente = cliente;
        this.direita = null;
        this.esquerda = null;

    }
}
