public class ControlarChamados {
    Chamado[] chamados = new Chamado[50];
    int quantidade = 0;

    public void adicionar(Chamado chamado) {
        if (quantidade < chamados.length) {
            chamados[quantidade] = chamado;
            quantidade++;
        } else {
            System.out.println("Limite de chamados atingido!");
        }
    }
    public Chamado buscar(int numero) {
        for (int i = 0; i < quantidade; i++) {
            if (chamados[i].numero == numero) {
                return chamados[i];
            }
        }

        return null;
    }
}
