public class Cliente {
    String documento;
    String nome;
    String telefone;
    String email;

    public Cliente ( String documento, String nome, String telefone, String email){
        this.documento = documento;
        this.nome = nome;
        this.telefone = telefone;
        this.email = email;
    }
}
