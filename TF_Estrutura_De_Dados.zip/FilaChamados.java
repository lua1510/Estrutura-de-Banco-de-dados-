public class FilaChamados {
    NoFila inicio;
    NoFila fim;

    public void adicionar (Chamado chamado){
        NoFila novo = new NoFila(chamado);

        if (inicio == null){
            inicio = novo;
            fim = novo;
        }else {
            fim.proximo = novo;
            fim = novo;

        }
    }

    public Chamado remover(){
        if (inicio == null){
            return null;
        }

        Chamado chamado = inicio.chamado;
        inicio = inicio.proximo;

        if (inicio == null) {
            fim = null;
        }

        return chamado;
    }
    public Chamado buscar(int numero) {
        NoFila atual = inicio;

        while (atual != null) {
            if (atual.chamado.numero == numero) {
                return atual.chamado;
            }

            atual = atual.proximo;
        }

        return null;
    }
    public void listar() {
        NoFila atual = inicio;

        if (atual == null) {
            System.out.println("Não existem chamados aguardando atendimento.");
            return;
        }

        while (atual != null) {
            System.out.println("Chamado: " + atual.chamado.numero);
            System.out.println("Assunto: " + atual.chamado.assunto);
            System.out.println("Status: " + atual.chamado.status);
            System.out.println("----------------------");

            atual = atual.proximo;
        }
    }
}
