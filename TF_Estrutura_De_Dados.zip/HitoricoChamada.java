public class HitoricoChamada {
     NoLista inicio;
        NoLista fim;

        public void adicionar(Mensagem mensagem) {
            NoLista novo = new NoLista(mensagem);

            if (inicio == null) {
                inicio = novo;
                fim = novo;
            } else {
                fim.proximo = novo;
                fim = novo;
            }
        }

        public Mensagem buscar(String conteudo) {
            NoLista atual = inicio;

            while (atual != null) {
                if (atual.mensagem.conteudo.equals(conteudo)) {
                    return atual.mensagem;
                }

                atual = atual.proximo;
            }

            return null;
        }

        public boolean remover(String conteudo) {
            NoLista atual = inicio;
            NoLista anterior = null;

            while (atual != null) {
                if (atual.mensagem.conteudo.equals(conteudo)) {
                    if (anterior == null) {
                        inicio = atual.proximo;
                    } else {
                        anterior.proximo = atual.proximo;
                    }

                    if (atual == fim) {
                        fim = anterior;
                    }

                    return true;
                }

                anterior = atual;
                atual = atual.proximo;
            }

            return false;
        }

        public void listar() {
            NoLista atual = inicio;

            while (atual != null) {
                System.out.println("Autor: " + atual.mensagem.autor);
                System.out.println("Mensagem: " + atual.mensagem.conteudo);
                System.out.println("----------------------");

                atual = atual.proximo;
            }
        }




    public boolean estaVazio() {
        return inicio == null;
    }

}
