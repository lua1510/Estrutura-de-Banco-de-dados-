public class NoFila {
    Chamado chamado;
    NoFila proximo;

    public NoFila(Chamado chamado) {
        this.chamado = chamado;
        this.proximo = null;
    }
}
